# Discwaal Stream Link Bot

A Telegram bot that:
- Accepts media from the admin
- Sends it to `@discwaal_bot`
- Waits for a stream link
- Sends a reply with either:
  - a thumbnail and link, or
  - just the link if no thumbnail

## 🔧 Setup

1. Get your API_ID and API_HASH from https://my.telegram.org
2. Generate a session string using Telethon
3. Install dependencies:

```bash
pip install -r requirements.txt
```

4. Run the bot:

```bash
python main.py
```

## ✏️ Config

Edit `main.py` and update these:

```python
API_ID = 123456
API_HASH = "your_api_hash"
BOT_TOKEN = "your_bot_token"
SESSION_STRING = "your_telethon_session_string"
ADMINS = [123456789]
BACKUP_CHANNEL = "@your_backup_channel"
```
